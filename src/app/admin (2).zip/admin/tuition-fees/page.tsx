"use client";

import { useEffect, useMemo, useState } from "react";
import styles from "./tuition-fees.module.css";
import { createClient } from "@/lib/supabase/client";

type Student = {
  id: string;
  name: string;
  admissionNumber: string;
  batchId: string | null;
  batchName: string;
};

type FeeStatus = "paid" | "pending" | "partial";

type FeeRecord = {
  id: string;
  student_id: string;
  batch_id: string | null;
  fee_name: string;
  amount: number;
  discount: number;
  paid_amount: number;
  due_date: string | null;
  status: FeeStatus;
  academic_year: string | null;
  created_at: string;
  updated_at: string;
  studentName: string;
  admissionNumber: string;
  batchName: string;
};

type FeeForm = {
  studentId: string;
  batchId: string;
  feeName: string;
  amount: string;
  discount: string;
  paidAmount: string;
  dueDate: string;
  academicYear: string;
};

const getLocalDate = () => {
  const now = new Date();
  const offset = now.getTimezoneOffset();
  return new Date(now.getTime() - offset * 60 * 1000)
    .toISOString()
    .slice(0, 10);
};

const getAcademicYear = () => {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth() + 1;
  const start = month >= 4 ? year : year - 1;
  return `${start}-${String(start + 1).slice(-2)}`;
};

const emptyForm: FeeForm = {
  studentId: "",
  batchId: "",
  feeName: "Tuition Fee",
  amount: "",
  discount: "0",
  paidAmount: "0",
  dueDate: "",
  academicYear: getAcademicYear(),
};

const money = (value: number) =>
  `₹${Math.max(0, Number(value || 0)).toLocaleString("en-IN", {
    maximumFractionDigits: 2,
  })}`;

const calculateStatus = (
  amount: number,
  discount: number,
  paid: number
): FeeStatus => {
  const payable = Math.max(0, amount - discount);
  if (paid >= payable && payable > 0) return "paid";
  if (paid > 0) return "partial";
  return "pending";
};

export default function TuitionFeesPage() {
  const supabase = createClient();

  const [activeFilter, setActiveFilter] = useState("All");
  const [showAddFee, setShowAddFee] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [students, setStudents] = useState<Student[]>([]);
  const [fees, setFees] = useState<FeeRecord[]>([]);
  const [form, setForm] = useState<FeeForm>(emptyForm);

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All Status");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const getInstitute = async () => {
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser();

    if (userError || !user) {
      throw new Error("Please login first.");
    }

    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("institute_id")
      .eq("id", user.id)
      .single();

    if (profileError || !profile?.institute_id) {
      throw new Error("Unable to load your institute profile.");
    }

    return profile.institute_id as string;
  };

  const loadData = async () => {
    setLoading(true);
    setError("");

    try {
      const instituteId = await getInstitute();

      const [
        { data: studentRows, error: studentError },
        { data: batchRows, error: batchError },
        { data: feeRows, error: feeError },
      ] = await Promise.all([
        supabase
          .from("students")
          .select(
            "id,first_name,middle_name,last_name,admission_number,batch_id"
          )
          .eq("institute_id", instituteId)
          .order("first_name", { ascending: true }),

        supabase
          .from("batches")
          .select("id,name")
          .eq("institute_id", instituteId)
          .order("name", { ascending: true }),

        supabase
          .from("tuition_fees")
          .select(
            "id,institute_id,student_id,batch_id,fee_name,amount,discount,paid_amount,due_date,status,academic_year,created_at,updated_at"
          )
          .eq("institute_id", instituteId)
          .order("created_at", { ascending: false }),
      ]);

      if (studentError) throw new Error(studentError.message);
      if (batchError) throw new Error(batchError.message);

      if (feeError) {
        if (feeError.message.includes("paid_amount")) {
          throw new Error(
            'The tuition_fees table is missing "paid_amount". Run the SQL migration shown below this step first.'
          );
        }
        throw new Error(feeError.message);
      }

      const batchMap = new Map<string, string>();
      (batchRows || []).forEach((batch: any) => {
        batchMap.set(batch.id, batch.name || "");
      });

      const studentMap = new Map<string, Student>();

      (studentRows || []).forEach((student: any) => {
        const name = [
          student.first_name,
          student.middle_name,
          student.last_name,
        ]
          .filter(Boolean)
          .join(" ");

        studentMap.set(student.id, {
          id: student.id,
          name: name || "Unnamed Student",
          admissionNumber: student.admission_number || "",
          batchId: student.batch_id || null,
          batchName: student.batch_id
            ? batchMap.get(student.batch_id) || ""
            : "",
        });
      });

      const mappedFees: FeeRecord[] = (feeRows || []).map((fee: any) => {
        const student = studentMap.get(fee.student_id);
        const amount = Number(fee.amount || 0);
        const discount = Number(fee.discount || 0);
        const paid = Number(fee.paid_amount || 0);

        return {
          id: fee.id,
          student_id: fee.student_id,
          batch_id: fee.batch_id || null,
          fee_name: fee.fee_name,
          amount,
          discount,
          paid_amount: paid,
          due_date: fee.due_date || null,
          status: calculateStatus(amount, discount, paid),
          academic_year: fee.academic_year || null,
          created_at: fee.created_at,
          updated_at: fee.updated_at,
          studentName: student?.name || "Unknown Student",
          admissionNumber: student?.admissionNumber || "",
          batchName: fee.batch_id
            ? batchMap.get(fee.batch_id) || ""
            : student?.batchName || "",
        };
      });

      setStudents(Array.from(studentMap.values()));
      setFees(mappedFees);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Unable to load tuition fees."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadData();
  }, []);

  const filteredFees = useMemo(() => {
    return fees.filter((fee) => {
      const matchesTab =
        activeFilter === "All" || fee.status === activeFilter.toLowerCase();

      const matchesSelect =
        statusFilter === "All Status" || fee.status === statusFilter.toLowerCase();

      const q = search.trim().toLowerCase();

      const matchesSearch =
        !q ||
        fee.studentName.toLowerCase().includes(q) ||
        fee.admissionNumber.toLowerCase().includes(q) ||
        fee.fee_name.toLowerCase().includes(q) ||
        fee.batchName.toLowerCase().includes(q);

      return matchesTab && matchesSelect && matchesSearch;
    });
  }, [fees, activeFilter, statusFilter, search]);

  const totals = useMemo(() => {
    let total = 0;
    let collected = 0;
    let pending = 0;

    fees.forEach((fee) => {
      total += Math.max(0, fee.amount - fee.discount);
      collected += Math.max(0, fee.paid_amount);
      pending += Math.max(
        0,
        fee.amount - fee.discount - fee.paid_amount
      );
    });

    return {
      total,
      collected,
      pending,
      records: fees.length,
    };
  }, [fees]);

  const openAdd = () => {
    setEditingId(null);
    setForm({
      ...emptyForm,
      studentId: students[0]?.id || "",
      batchId: students[0]?.batchId || "",
      dueDate: getLocalDate(),
      academicYear: getAcademicYear(),
    });
    setError("");
    setSuccess("");
    setShowAddFee(true);
  };

  const openEdit = (fee: FeeRecord) => {
    setEditingId(fee.id);
    setForm({
      studentId: fee.student_id,
      batchId: fee.batch_id || "",
      feeName: fee.fee_name || "Tuition Fee",
      amount: String(fee.amount),
      discount: String(fee.discount),
      paidAmount: String(fee.paid_amount),
      dueDate: fee.due_date || "",
      academicYear: fee.academic_year || getAcademicYear(),
    });
    setError("");
    setSuccess("");
    setShowAddFee(true);
  };

  const handleStudentChange = (studentId: string) => {
    const student = students.find((item) => item.id === studentId);

    setForm((previous) => ({
      ...previous,
      studentId,
      batchId: student?.batchId || "",
    }));
  };

  const saveFee = async () => {
    if (!form.studentId) {
      setError("Please select a student.");
      return;
    }

    const amount = Number(form.amount);
    const discount = Number(form.discount || 0);
    const paidAmount = Number(form.paidAmount || 0);

    if (!Number.isFinite(amount) || amount <= 0) {
      setError("Total Fee must be greater than 0.");
      return;
    }

    if (!Number.isFinite(discount) || discount < 0) {
      setError("Discount cannot be negative.");
      return;
    }

    if (discount > amount) {
      setError("Discount cannot be greater than Total Fee.");
      return;
    }

    const payable = Math.max(0, amount - discount);

    if (!Number.isFinite(paidAmount) || paidAmount < 0) {
      setError("Paid Amount cannot be negative.");
      return;
    }

    if (paidAmount > payable) {
      setError("Paid Amount cannot be greater than payable amount.");
      return;
    }

    setSaving(true);
    setError("");
    setSuccess("");

    try {
      const instituteId = await getInstitute();

      const payload = {
        institute_id: instituteId,
        student_id: form.studentId,
        batch_id: form.batchId || null,
        fee_name: form.feeName.trim() || "Tuition Fee",
        amount,
        discount,
        paid_amount: paidAmount,
        due_date: form.dueDate || null,
        status: calculateStatus(amount, discount, paidAmount),
        academic_year: form.academicYear.trim() || getAcademicYear(),
      };

      const result = editingId
        ? await supabase
            .from("tuition_fees")
            .update(payload)
            .eq("id", editingId)
            .eq("institute_id", instituteId)
        : await supabase.from("tuition_fees").insert(payload);

      if (result.error) {
        throw new Error(result.error.message);
      }

      setShowAddFee(false);
      setEditingId(null);

      setSuccess(
        editingId
          ? "Fee record updated successfully."
          : "Fee record saved successfully."
      );

      await loadData();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Unable to save fee record."
      );
    } finally {
      setSaving(false);
    }
  };

  const deleteFee = async (fee: FeeRecord) => {
    const confirmed = window.confirm(
      `Delete ${fee.fee_name} for ${fee.studentName}?`
    );

    if (!confirmed) return;

    try {
      setError("");
      const instituteId = await getInstitute();

      const { error: deleteError } = await supabase
        .from("tuition_fees")
        .delete()
        .eq("id", fee.id)
        .eq("institute_id", instituteId);

      if (deleteError) throw new Error(deleteError.message);

      setSuccess("Fee record deleted successfully.");
      await loadData();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Unable to delete fee record."
      );
    }
  };

  const exportCsv = () => {
    if (!filteredFees.length) {
      setError("No fee records available to export.");
      return;
    }

    const headers = [
      "Student",
      "Admission No",
      "Batch",
      "Fee",
      "Amount",
      "Discount",
      "Paid",
      "Pending",
      "Due Date",
      "Status",
      "Academic Year",
    ];

    const rows = filteredFees.map((fee) => [
      fee.studentName,
      fee.admissionNumber,
      fee.batchName,
      fee.fee_name,
      fee.amount,
      fee.discount,
      fee.paid_amount,
      Math.max(0, fee.amount - fee.discount - fee.paid_amount),
      fee.due_date || "",
      fee.status,
      fee.academic_year || "",
    ]);

    const csv = [headers, ...rows]
      .map((row) =>
        row
          .map((value) => `"${String(value).replace(/"/g, '""')}"`)
          .join(",")
      )
      .join("\n");

    const blob = new Blob([csv], {
      type: "text/csv;charset=utf-8;",
    });

    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "tuition-fees.csv";
    anchor.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className={styles.page}>
      <div className={styles.pageHeader}>
        <div>
          <div className={styles.eyebrow}>FINANCE MANAGEMENT</div>

          <h1>
            Tuition <span>Fees</span>
          </h1>

          <p>
            Manage student fees, payments and pending balances
            from one organized workspace.
          </p>
        </div>

        <div className={styles.headerActions}>
          <button className={styles.exportButton} onClick={exportCsv}>
            ↓
            <span>Export</span>
          </button>

          <button className={styles.addButton} onClick={openAdd}>
            +
            <span>Add Fee</span>
          </button>
        </div>
      </div>

      {error && (
        <div
          style={{
            marginBottom: 20,
            padding: "13px 16px",
            borderRadius: 12,
            border: "1px solid #fecaca",
            background: "#fff1f2",
            color: "#be123c",
          }}
        >
          {error}
        </div>
      )}

      {success && (
        <div
          style={{
            marginBottom: 20,
            padding: "13px 16px",
            borderRadius: 12,
            border: "1px solid #a7f3d0",
            background: "#ecfdf5",
            color: "#047857",
          }}
        >
          {success}
        </div>
      )}

      <div className={styles.statsGrid}>
        <div className={`${styles.statCard} ${styles.purpleCard}`}>
          <div className={styles.statIcon}>₹</div>
          <div>
            <p>Total Fees</p>
            <strong>{loading ? "..." : money(totals.total)}</strong>
            <small>Net payable amount</small>
          </div>
        </div>

        <div className={`${styles.statCard} ${styles.greenCard}`}>
          <div className={styles.statIcon}>✓</div>
          <div>
            <p>Total Collected</p>
            <strong>{loading ? "..." : money(totals.collected)}</strong>
            <small>Amount received</small>
          </div>
        </div>

        <div className={`${styles.statCard} ${styles.orangeCard}`}>
          <div className={styles.statIcon}>!</div>
          <div>
            <p>Pending Fees</p>
            <strong>{loading ? "..." : money(totals.pending)}</strong>
            <small>Amount remaining</small>
          </div>
        </div>

        <div className={`${styles.statCard} ${styles.blueCard}`}>
          <div className={styles.statIcon}>#</div>
          <div>
            <p>Fee Records</p>
            <strong>{loading ? "..." : totals.records}</strong>
            <small>Database records</small>
          </div>
        </div>
      </div>

      <section className={styles.directory}>
        <div className={styles.directoryHeader}>
          <div>
            <div className={styles.eyebrow}>FEE DIRECTORY</div>

            <h2>All Fee Records</h2>

            <p>
              View and manage student tuition fee information.
            </p>
          </div>

          <button className={styles.recordButton} onClick={openAdd}>
            + Record Payment
          </button>
        </div>

        <div className={styles.filterBar}>
          <div className={styles.filters}>
            {["All", "Paid", "Pending", "Partial"].map((filter) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={
                  activeFilter === filter
                    ? styles.activeFilter
                    : styles.filterButton
                }
              >
                {filter}
                {filter !== "All"
                  ? ` (${fees.filter((fee) => fee.status === filter.toLowerCase()).length})`
                  : ` (${fees.length})`}
              </button>
            ))}
          </div>

          <select
            className={styles.select}
            value={statusFilter}
            onChange={(event) => setStatusFilter(event.target.value)}
          >
            <option>All Status</option>
            <option>Paid</option>
            <option>Pending</option>
            <option>Partial</option>
          </select>

          <input
            className={styles.search}
            type="text"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="⌕  Search student..."
          />
        </div>

        {loading ? (
          <div className={styles.emptyState}>
            <div className={styles.emptyIcon}>₹</div>
            <h3>Loading fee records...</h3>
            <p>Fetching fee records from Supabase.</p>
          </div>
        ) : filteredFees.length === 0 ? (
          <div className={styles.emptyState}>
            <div className={styles.emptyIcon}>₹</div>

            <h3>No fee records yet</h3>

            <p>
              {fees.length
                ? "No records match your current filters."
                : "Student fee information will appear here after you add the first fee record."}
            </p>

            {!fees.length && (
              <button className={styles.emptyButton} onClick={openAdd}>
                + Add First Fee
              </button>
            )}
          </div>
        ) : (
          <div
            style={{
              padding: "20px 24px 28px",
              display: "grid",
              gap: 14,
            }}
          >
            {filteredFees.map((fee) => {
              const payable = Math.max(0, fee.amount - fee.discount);
              const pending = Math.max(
                0,
                payable - fee.paid_amount
              );

              return (
                <div
                  key={fee.id}
                  style={{
                    border: "1px solid #e1e6f2",
                    borderRadius: 16,
                    padding: "18px 20px",
                    background: "#fff",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      gap: 16,
                      flexWrap: "wrap",
                    }}
                  >
                    <div>
                      <strong
                        style={{
                          display: "block",
                          fontSize: 18,
                          color: "#17213f",
                        }}
                      >
                        {fee.studentName}
                      </strong>

                      <span
                        style={{
                          color: "#7380a2",
                          fontSize: 13,
                        }}
                      >
                        {fee.admissionNumber
                          ? `${fee.admissionNumber} • `
                          : ""}
                        {fee.batchName || "No batch"}
                      </span>
                    </div>

                    <span
                      style={{
                        alignSelf: "flex-start",
                        padding: "7px 12px",
                        borderRadius: 999,
                        fontSize: 13,
                        fontWeight: 700,
                        color:
                          fee.status === "paid"
                            ? "#047857"
                            : fee.status === "partial"
                              ? "#b45309"
                              : "#dc2626",
                        background:
                          fee.status === "paid"
                            ? "#ecfdf5"
                            : fee.status === "partial"
                              ? "#fff7ed"
                              : "#fff1f2",
                      }}
                    >
                      {fee.status}
                    </span>
                  </div>

                  <div
                    style={{
                      display: "grid",
                      gridTemplateColumns:
                        "repeat(auto-fit,minmax(130px,1fr))",
                      gap: 14,
                      marginTop: 18,
                    }}
                  >
                    <div>
                      <small>Fee</small>
                      <strong
                        style={{
                          display: "block",
                          marginTop: 4,
                        }}
                      >
                        {fee.fee_name}
                      </strong>
                    </div>

                    <div>
                      <small>Total</small>
                      <strong
                        style={{
                          display: "block",
                          marginTop: 4,
                        }}
                      >
                        {money(fee.amount)}
                      </strong>
                    </div>

                    <div>
                      <small>Discount</small>
                      <strong
                        style={{
                          display: "block",
                          marginTop: 4,
                        }}
                      >
                        {money(fee.discount)}
                      </strong>
                    </div>

                    <div>
                      <small>Paid</small>
                      <strong
                        style={{
                          display: "block",
                          marginTop: 4,
                          color: "#059669",
                        }}
                      >
                        {money(fee.paid_amount)}
                      </strong>
                    </div>

                    <div>
                      <small>Pending</small>
                      <strong
                        style={{
                          display: "block",
                          marginTop: 4,
                          color: pending > 0 ? "#dc2626" : "#059669",
                        }}
                      >
                        {money(pending)}
                      </strong>
                    </div>

                    <div>
                      <small>Due Date</small>
                      <strong
                        style={{
                          display: "block",
                          marginTop: 4,
                        }}
                      >
                        {fee.due_date
                          ? new Date(
                              `${fee.due_date}T00:00:00`
                            ).toLocaleDateString("en-IN")
                          : "—"}
                      </strong>
                    </div>
                  </div>

                  <div
                    style={{
                      display: "flex",
                      justifyContent: "flex-end",
                      gap: 8,
                      marginTop: 16,
                    }}
                  >
                    <button
                      type="button"
                      onClick={() => openEdit(fee)}
                      style={{
                        border: "1px solid #dbe1ef",
                        background: "#fff",
                        borderRadius: 9,
                        padding: "8px 14px",
                        cursor: "pointer",
                        fontWeight: 600,
                      }}
                    >
                      Edit
                    </button>

                    <button
                      type="button"
                      onClick={() => void deleteFee(fee)}
                      style={{
                        border: "1px solid #fecaca",
                        background: "#fff1f2",
                        color: "#dc2626",
                        borderRadius: 9,
                        padding: "8px 14px",
                        cursor: "pointer",
                        fontWeight: 600,
                      }}
                    >
                      Delete
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {showAddFee && (
        <div
          className={styles.modalOverlay}
          onClick={() => !saving && setShowAddFee(false)}
        >
          <div
            className={styles.modal}
            onClick={(event) => event.stopPropagation()}
          >
            <div className={styles.modalHeader}>
              <div>
                <span>FEE MANAGEMENT</span>
                <h2>{editingId ? "Edit Fee Record" : "Add Fee Record"}</h2>
              </div>

              <button
                className={styles.closeButton}
                onClick={() => !saving && setShowAddFee(false)}
                disabled={saving}
              >
                ×
              </button>
            </div>

            <div className={styles.form}>
              <div className={styles.inputGroup}>
                <label>Student</label>

                <select
                  value={form.studentId}
                  onChange={(event) =>
                    handleStudentChange(event.target.value)
                  }
                >
                  <option value="">
                    {students.length
                      ? "Select student"
                      : "No students available"}
                  </option>

                  {students.map((student) => (
                    <option key={student.id} value={student.id}>
                      {student.name}
                      {student.admissionNumber
                        ? ` — ${student.admissionNumber}`
                        : ""}
                    </option>
                  ))}
                </select>
              </div>

              <div className={styles.inputGroup}>
                <label>Fee Name</label>

                <input
                  type="text"
                  value={form.feeName}
                  onChange={(event) =>
                    setForm({
                      ...form,
                      feeName: event.target.value,
                    })
                  }
                  placeholder="Tuition Fee"
                />
              </div>

              <div className={styles.inputGroup}>
                <label>Total Fee</label>

                <input
                  type="number"
                  min="0"
                  value={form.amount}
                  onChange={(event) =>
                    setForm({
                      ...form,
                      amount: event.target.value,
                    })
                  }
                  placeholder="₹ 0"
                />
              </div>

              <div className={styles.inputGroup}>
                <label>Discount</label>

                <input
                  type="number"
                  min="0"
                  value={form.discount}
                  onChange={(event) =>
                    setForm({
                      ...form,
                      discount: event.target.value,
                    })
                  }
                  placeholder="₹ 0"
                />
              </div>

              <div className={styles.inputGroup}>
                <label>Paid Amount</label>

                <input
                  type="number"
                  min="0"
                  value={form.paidAmount}
                  onChange={(event) =>
                    setForm({
                      ...form,
                      paidAmount: event.target.value,
                    })
                  }
                  placeholder="₹ 0"
                />
              </div>

              <div className={styles.inputGroup}>
                <label>Due Date</label>

                <input
                  type="date"
                  value={form.dueDate}
                  onChange={(event) =>
                    setForm({
                      ...form,
                      dueDate: event.target.value,
                    })
                  }
                />
              </div>

              <div className={styles.inputGroup}>
                <label>Academic Year</label>

                <input
                  type="text"
                  value={form.academicYear}
                  onChange={(event) =>
                    setForm({
                      ...form,
                      academicYear: event.target.value,
                    })
                  }
                  placeholder="2026-27"
                />
              </div>

              <div
                style={{
                  padding: "12px 14px",
                  borderRadius: 10,
                  background: "#f7f8fc",
                  color: "#4f5d80",
                  fontSize: 14,
                }}
              >
                Payable:{" "}
                <strong>
                  {money(
                    Math.max(
                      0,
                      Number(form.amount || 0) -
                        Number(form.discount || 0)
                    )
                  )}
                </strong>
                {" • "}
                Pending:{" "}
                <strong>
                  {money(
                    Math.max(
                      0,
                      Number(form.amount || 0) -
                        Number(form.discount || 0) -
                        Number(form.paidAmount || 0)
                    )
                  )}
                </strong>
              </div>

              <div className={styles.modalActions}>
                <button
                  className={styles.cancelButton}
                  onClick={() => setShowAddFee(false)}
                  disabled={saving}
                >
                  Cancel
                </button>

                <button
                  className={styles.saveButton}
                  onClick={() => void saveFee()}
                  disabled={saving || !students.length}
                >
                  {saving
                    ? "Saving..."
                    : editingId
                      ? "Update Fee"
                      : "Save Fee"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
